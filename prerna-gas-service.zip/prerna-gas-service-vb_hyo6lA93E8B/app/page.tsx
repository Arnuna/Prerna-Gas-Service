"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { 
  MessageSquare, 
  Calendar, 
  Phone, 
  Star, 
  Flame, 
  Wrench, 
  Shield, 
  PhoneCall,
  MessageCircle,
  CheckCircle,
  AlertTriangle,
  Home,
  Building2,
  ClipboardCheck,
  CreditCard
} from "lucide-react"
import { APP_CONFIG } from "@/lib/app-config"
import InquirySection from "@/components/inquiry-section"
import BookingSection from "@/components/booking-section"
import ContactSection from "@/components/contact-section"
import ReviewSection from "@/components/review-section"
import ChatbotSection from "@/components/chatbot-section"
import PaymentSection from "@/components/payment-section"
import PiStatusIndicator from "@/components/pi-status-indicator"
import { trackVisitor } from "@/app/actions/notifications"

export default function PrernGasServiceApp() {
  const [activeTab, setActiveTab] = useState("home")
  const [showChatbot, setShowChatbot] = useState(false)

  // Track visitor on initial page load
  useEffect(() => {
    trackVisitor({
      action: 'App opened - Initial visit',
      timestamp: new Date().toISOString(),
    })
  }, [])

  // Track tab changes
  const handleTabChange = (value: string) => {
    setActiveTab(value)
    trackVisitor({
      action: `Navigated to ${value} section`,
      timestamp: new Date().toISOString(),
    })
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 w-full border-b bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60">
        <div className="container flex h-16 items-center px-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary">
              <Flame className="h-6 w-6 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-foreground">{APP_CONFIG.NAME}</h1>
              <p className="text-xs text-muted-foreground">{APP_CONFIG.DESCRIPTION}</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container pb-24 pt-6 px-4">
        <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
          <TabsList className="grid w-full grid-cols-5 mb-6">
            <TabsTrigger value="home" className="text-xs">
              <Home className="h-4 w-4 mr-1" />
              Home
            </TabsTrigger>
            <TabsTrigger value="inquiry" className="text-xs">
              <MessageSquare className="h-4 w-4 mr-1" />
              Inquiry
            </TabsTrigger>
            <TabsTrigger value="booking" className="text-xs">
              <Calendar className="h-4 w-4 mr-1" />
              Book
            </TabsTrigger>
            <TabsTrigger value="payment" className="text-xs">
              <CreditCard className="h-4 w-4 mr-1" />
              Pay
            </TabsTrigger>
            <TabsTrigger value="contact" className="text-xs">
              <Phone className="h-4 w-4 mr-1" />
              Contact
            </TabsTrigger>
          </TabsList>

          {/* Home Tab */}
          <TabsContent value="home" className="space-y-6">
            {/* Hero Section */}
            <Card className="border-2 border-primary/20 bg-gradient-to-br from-primary/5 to-secondary/5">
              <CardHeader className="text-center pb-4">
                <div className="flex justify-center mb-3">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary">
                    <Flame className="h-10 w-10 text-primary-foreground" />
                  </div>
                </div>
                <CardTitle className="text-2xl text-balance">Reliable LPG Services</CardTitle>
                <CardDescription className="text-base">
                  Professional gas solutions for homes and businesses across North Bengal & Sikkim
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3 pb-6">
                <div className="flex items-center gap-3 p-3 rounded-lg bg-card">
                  <Shield className="h-5 w-5 text-primary flex-shrink-0" />
                  <p className="text-sm text-muted-foreground">
                    Certified & Safety Compliant Services
                  </p>
                </div>
                <div className="flex items-center gap-3 p-3 rounded-lg bg-card">
                  <CheckCircle className="h-5 w-5 text-success flex-shrink-0" />
                  <p className="text-sm text-muted-foreground">
                    Serving North Bengal & Sikkim Region
                  </p>
                </div>
                <div className="flex items-center gap-3 p-3 rounded-lg bg-card">
                  <AlertTriangle className="h-5 w-5 text-secondary flex-shrink-0" />
                  <p className="text-sm text-muted-foreground">
                    24/7 Emergency Support Available
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Services Grid */}
            <div className="space-y-3">
              <h2 className="text-xl font-bold text-foreground">Our Services</h2>
              <div className="grid grid-cols-1 gap-3">
                <Card className="hover:shadow-md transition-shadow">
                  <CardContent className="flex items-start gap-4 p-4">
                    <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 flex-shrink-0">
                      <Flame className="h-6 w-6 text-primary" />
                    </div>
                    <div className="flex-1 space-y-1">
                      <h3 className="font-semibold text-foreground">LPG Burner Servicing</h3>
                      <p className="text-sm text-muted-foreground">
                        Professional cleaning, maintenance, and repair of domestic and commercial LPG burners
                      </p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="hover:shadow-md transition-shadow">
                  <CardContent className="flex items-start gap-4 p-4">
                    <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-secondary/10 flex-shrink-0">
                      <Wrench className="h-6 w-6 text-secondary" />
                    </div>
                    <div className="flex-1 space-y-1">
                      <h3 className="font-semibold text-foreground">Pipeline Installation</h3>
                      <p className="text-sm text-muted-foreground">
                        Safe and compliant gas pipeline installation for homes and businesses
                      </p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="hover:shadow-md transition-shadow">
                  <CardContent className="flex items-start gap-4 p-4">
                    <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 flex-shrink-0">
                      <ClipboardCheck className="h-6 w-6 text-primary" />
                    </div>
                    <div className="flex-1 space-y-1">
                      <h3 className="font-semibold text-foreground">Safety Inspections</h3>
                      <p className="text-sm text-muted-foreground">
                        Comprehensive gas leakage checking and safety assessments
                      </p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="hover:shadow-md transition-shadow">
                  <CardContent className="flex items-start gap-4 p-4">
                    <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-secondary/10 flex-shrink-0">
                      <Shield className="h-6 w-6 text-secondary" />
                    </div>
                    <div className="flex-1 space-y-1">
                      <h3 className="font-semibold text-foreground">Repair & Maintenance</h3>
                      <p className="text-sm text-muted-foreground">
                        Expert repair services and preventive maintenance programs
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Service Types */}
            <div className="space-y-3">
              <h2 className="text-xl font-bold text-foreground">We Serve</h2>
              <div className="grid grid-cols-2 gap-3">
                <Card className="bg-gradient-to-br from-primary/5 to-transparent">
                  <CardContent className="flex flex-col items-center justify-center p-6 text-center">
                    <Home className="h-10 w-10 text-primary mb-3" />
                    <h3 className="font-semibold text-foreground mb-1">Residential</h3>
                    <p className="text-xs text-muted-foreground">Home & Apartment Services</p>
                  </CardContent>
                </Card>
                <Card className="bg-gradient-to-br from-secondary/5 to-transparent">
                  <CardContent className="flex flex-col items-center justify-center p-6 text-center">
                    <Building2 className="h-10 w-10 text-secondary mb-3" />
                    <h3 className="font-semibold text-foreground mb-1">Commercial</h3>
                    <p className="text-xs text-muted-foreground">Business & Restaurant Services</p>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Quick Actions */}
            <Card className="border-primary/30">
              <CardHeader>
                <CardTitle className="text-lg">Quick Actions</CardTitle>
                <CardDescription>Get started with our services</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button 
                  className="w-full justify-start" 
                  variant="default"
                  onClick={() => setActiveTab("inquiry")}
                >
                  <MessageSquare className="h-5 w-5 mr-2" />
                  Send Inquiry
                </Button>
                <Button 
                  className="w-full justify-start" 
                  variant="outline"
                  onClick={() => setActiveTab("booking")}
                >
                  <Calendar className="h-5 w-5 mr-2" />
                  Book Service
                </Button>
                <Button 
                  className="w-full justify-start" 
                  variant="outline"
                  onClick={() => setActiveTab("payment")}
                >
                  <CreditCard className="h-5 w-5 mr-2" />
                  Make Payment
                </Button>
                <Button 
                  className="w-full justify-start" 
                  variant="outline"
                  onClick={() => setShowChatbot(true)}
                >
                  <MessageCircle className="h-5 w-5 mr-2" />
                  Chat with AI Assistant
                </Button>
              </CardContent>
            </Card>

            {/* Reviews Preview */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Star className="h-5 w-5 text-secondary fill-secondary" />
                  Customer Reviews
                </CardTitle>
                <CardDescription>See what our customers say</CardDescription>
              </CardHeader>
              <CardContent>
                <Button 
                  className="w-full" 
                  variant="outline"
                  onClick={() => window.location.hash = "review"}
                >
                  View & Submit Reviews
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Inquiry Tab */}
          <TabsContent value="inquiry">
            <InquirySection onOpenChatbot={() => setShowChatbot(true)} />
          </TabsContent>

          {/* Booking Tab */}
          <TabsContent value="booking">
            <BookingSection />
          </TabsContent>

          {/* Payment Tab */}
          <TabsContent value="payment">
            <PaymentSection />
          </TabsContent>

          {/* Contact Tab */}
          <TabsContent value="contact">
            <ContactSection />
          </TabsContent>
        </Tabs>

        {/* Review Section - Always visible at bottom */}
        <div id="review" className="mt-8">
          <ReviewSection />
        </div>
      </main>

      {/* AI Chatbot Floating Button */}
      {!showChatbot && (
        <Button
          onClick={() => setShowChatbot(true)}
          className="fixed bottom-20 right-4 h-14 w-14 rounded-full shadow-lg hover:scale-110 transition-transform z-50"
          size="icon"
        >
          <MessageCircle className="h-6 w-6" />
        </Button>
      )}

      {/* AI Chatbot Modal */}
      {showChatbot && (
        <ChatbotSection onClose={() => setShowChatbot(false)} />
      )}

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 border-t bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60">
        <div className="container flex h-16 items-center justify-around px-4">
          <Button
            variant={activeTab === "home" ? "default" : "ghost"}
            size="sm"
            className="flex flex-col h-auto py-2 px-3"
            onClick={() => setActiveTab("home")}
          >
            <Home className="h-5 w-5 mb-1" />
            <span className="text-xs">Home</span>
          </Button>
          <Button
            variant={activeTab === "inquiry" ? "default" : "ghost"}
            size="sm"
            className="flex flex-col h-auto py-2 px-3"
            onClick={() => setActiveTab("inquiry")}
          >
            <MessageSquare className="h-5 w-5 mb-1" />
            <span className="text-xs">Inquiry</span>
          </Button>
          <Button
            variant={activeTab === "booking" ? "default" : "ghost"}
            size="sm"
            className="flex flex-col h-auto py-2 px-3"
            onClick={() => setActiveTab("booking")}
          >
            <Calendar className="h-5 w-5 mb-1" />
            <span className="text-xs">Book</span>
          </Button>
          <Button
            variant={activeTab === "payment" ? "default" : "ghost"}
            size="sm"
            className="flex flex-col h-auto py-2 px-3"
            onClick={() => setActiveTab("payment")}
          >
            <CreditCard className="h-5 w-5 mb-1" />
            <span className="text-xs">Pay</span>
          </Button>
          <Button
            variant={activeTab === "contact" ? "default" : "ghost"}
            size="sm"
            className="flex flex-col h-auto py-2 px-3"
            onClick={() => setActiveTab("contact")}
          >
            <Phone className="h-5 w-5 mb-1" />
            <span className="text-xs">Contact</span>
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="flex flex-col h-auto py-2 px-3"
            onClick={() => window.location.hash = "review"}
          >
            <Star className="h-5 w-5 mb-1" />
            <span className="text-xs">Review</span>
          </Button>
        </div>
      </nav>

      {/* Pi SDK Status Indicator */}
      <PiStatusIndicator />

      {/* Chatbot Modal */}
      {showChatbot && (
        <ChatbotSection onClose={() => setShowChatbot(false)} />
      )}
    </div>
  )
}
