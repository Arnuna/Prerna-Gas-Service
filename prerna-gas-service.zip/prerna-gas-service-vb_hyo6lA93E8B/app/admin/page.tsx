"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Bell, MessageSquare, Calendar, Star, Eye, ExternalLink } from "lucide-react"
import { getNotifications } from "@/app/actions/notifications"
import type { NotificationData } from "@/lib/notification-service"
import { getWhatsAppURL, formatNotificationMessage } from "@/lib/notification-service"

export default function AdminNotifications() {
  const [notifications, setNotifications] = useState<NotificationData[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadNotifications()
    // Refresh every 10 seconds
    const interval = setInterval(loadNotifications, 10000)
    return () => clearInterval(interval)
  }, [])

  const loadNotifications = async () => {
    const data = await getNotifications()
    setNotifications(data.reverse()) // Show newest first
    setLoading(false)
  }

  const getIcon = (type: string) => {
    switch (type) {
      case 'inquiry': return <MessageSquare className="h-5 w-5" />
      case 'booking': return <Calendar className="h-5 w-5" />
      case 'review': return <Star className="h-5 w-5" />
      case 'visit': return <Eye className="h-5 w-5" />
      default: return <Bell className="h-5 w-5" />
    }
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'inquiry': return 'bg-blue-500/10 text-blue-500'
      case 'booking': return 'bg-green-500/10 text-green-500'
      case 'review': return 'bg-yellow-500/10 text-yellow-500'
      case 'visit': return 'bg-purple-500/10 text-purple-500'
      default: return 'bg-gray-500/10 text-gray-500'
    }
  }

  const sendToWhatsApp = (notification: NotificationData) => {
    const message = formatNotificationMessage(notification)
    const url = getWhatsAppURL(message)
    window.open(url, '_blank')
  }

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="container max-w-4xl mx-auto space-y-6">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-2xl">Admin Notifications</CardTitle>
                <CardDescription>
                  Monitor all customer activities in real-time
                </CardDescription>
              </div>
              <Badge variant="secondary" className="text-lg px-3 py-1">
                {notifications.length}
              </Badge>
            </div>
          </CardHeader>
        </Card>

        {loading ? (
          <Card>
            <CardContent className="p-8 text-center text-muted-foreground">
              Loading notifications...
            </CardContent>
          </Card>
        ) : notifications.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <Bell className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-muted-foreground">No notifications yet</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {notifications.map((notification, index) => (
              <Card key={index} className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${getTypeColor(notification.type)}`}>
                      {getIcon(notification.type)}
                    </div>
                    <div className="flex-1 space-y-2">
                      <div className="flex items-center justify-between">
                        <Badge variant="outline" className="capitalize">
                          {notification.type}
                        </Badge>
                        <span className="text-xs text-muted-foreground">
                          {new Date(notification.timestamp).toLocaleString('en-IN', {
                            timeZone: 'Asia/Kolkata',
                            dateStyle: 'short',
                            timeStyle: 'short',
                          })}
                        </span>
                      </div>
                      
                      <div className="space-y-1 text-sm">
                        {notification.userName && (
                          <div className="flex gap-2">
                            <span className="text-muted-foreground">Name:</span>
                            <span className="font-medium">{notification.userName}</span>
                          </div>
                        )}
                        {notification.serviceType && (
                          <div className="flex gap-2">
                            <span className="text-muted-foreground">Service:</span>
                            <span className="font-medium">{notification.serviceType}</span>
                          </div>
                        )}
                        {notification.location && (
                          <div className="flex gap-2">
                            <span className="text-muted-foreground">Location:</span>
                            <span className="font-medium">{notification.location}</span>
                          </div>
                        )}
                        {notification.contactNumber && (
                          <div className="flex gap-2">
                            <span className="text-muted-foreground">Contact:</span>
                            <span className="font-medium">{notification.contactNumber}</span>
                          </div>
                        )}
                        {notification.rating && (
                          <div className="flex gap-2">
                            <span className="text-muted-foreground">Rating:</span>
                            <span className="font-medium">⭐ {notification.rating}/5</span>
                          </div>
                        )}
                        {notification.message && (
                          <div className="flex gap-2">
                            <span className="text-muted-foreground">Message:</span>
                            <span className="font-medium">{notification.message}</span>
                          </div>
                        )}
                      </div>

                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="w-full mt-2"
                        onClick={() => sendToWhatsApp(notification)}
                      >
                        <ExternalLink className="h-4 w-4 mr-2" />
                        Send to WhatsApp
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
