"use client"

import { useEffect, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { X, Bot, ExternalLink } from "lucide-react"

interface ChatbotSectionProps {
  onClose: () => void
}

export default function ChatbotSection({ onClose }: ChatbotSectionProps) {
  const iframeRef = useRef<HTMLIFrameElement>(null)

  useEffect(() => {
    // Set page title when chatbot opens
    document.title = "Made with App Studio"
  }, [])

  return (
    <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm">
      <div className="fixed inset-0 flex items-center justify-center p-4">
        <Card className="w-full max-w-2xl h-[600px] max-h-[85vh] flex flex-col shadow-2xl">
          <CardHeader className="flex-row items-center justify-between space-y-0 pb-4 bg-primary text-primary-foreground rounded-t-lg">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary-foreground/20">
                <Bot className="h-6 w-6" />
              </div>
              <div>
                <CardTitle className="text-lg">AI Service Assistant</CardTitle>
                <p className="text-xs opacity-90">Powered by Prerna Gas Service</p>
              </div>
            </div>
            <Button 
              variant="ghost" 
              size="icon"
              onClick={onClose}
              className="text-primary-foreground hover:bg-primary-foreground/20"
            >
              <X className="h-5 w-5" />
            </Button>
          </CardHeader>
          
          <CardContent className="flex-1 p-0 overflow-hidden">
            <div className="relative w-full h-full">
              <iframe
                ref={iframeRef}
                src="https://yasai9061.pinet.com"
                className="w-full h-full border-0"
                title="Prerna Gas Service AI Assistant"
                allow="microphone; camera"
                sandbox="allow-same-origin allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox"
              />
            </div>
          </CardContent>

          <div className="p-4 border-t bg-muted/30">
            <div className="flex items-center justify-between">
              <p className="text-xs text-muted-foreground">
                AI-powered assistance for all service inquiries
              </p>
              <Button
                variant="ghost"
                size="sm"
                className="text-xs gap-1"
                onClick={() => window.open("https://yasai9061.pinet.com", "_blank")}
              >
                Open in new tab
                <ExternalLink className="h-3 w-3" />
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}
