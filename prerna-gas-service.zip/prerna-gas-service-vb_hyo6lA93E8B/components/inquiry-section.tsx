"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { MessageCircle, DollarSign, ClipboardCheck, AlertCircle, Wrench, Shield } from "lucide-react"
import { sendNotification } from "@/app/actions/notifications"

interface InquirySectionProps {
  onOpenChatbot: () => void
}

export default function InquirySection({ onOpenChatbot }: InquirySectionProps) {
  const handleInquiryClick = async (topic: string) => {
    // Send notification to app owner
    await sendNotification({
      type: 'inquiry',
      serviceType: topic,
      message: `User opened inquiry about: ${topic}`,
      timestamp: new Date().toISOString(),
    })
    
    // Open chatbot
    onOpenChatbot()
  }

  const inquiryTopics = [
    {
      icon: DollarSign,
      title: "Service Pricing",
      description: "Get detailed pricing for all our LPG services",
      color: "text-primary",
      bgColor: "bg-primary/10"
    },
    {
      icon: ClipboardCheck,
      title: "Safety Inspection",
      description: "Learn about our comprehensive safety check process",
      color: "text-success",
      bgColor: "bg-success/10"
    },
    {
      icon: Wrench,
      title: "Service Details",
      description: "Understand our service offerings and procedures",
      color: "text-secondary",
      bgColor: "bg-secondary/10"
    },
    {
      icon: AlertCircle,
      title: "Emergency Support",
      description: "24/7 emergency gas service and leakage support",
      color: "text-destructive",
      bgColor: "bg-destructive/10"
    },
    {
      icon: Shield,
      title: "Warranty & Guarantee",
      description: "Know about our service warranty and guarantees",
      color: "text-primary",
      bgColor: "bg-primary/10"
    }
  ]

  return (
    <div className="space-y-6">
      {/* Header Card */}
      <Card className="border-primary/30 bg-gradient-to-br from-primary/5 to-transparent">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl text-balance">Have Questions?</CardTitle>
          <CardDescription className="text-base">
            Get instant answers about our LPG services, pricing, and safety procedures
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Button 
            className="w-full" 
            size="lg"
            onClick={onOpenChatbot}
          >
            <MessageCircle className="h-5 w-5 mr-2" />
            Chat with AI Assistant
          </Button>
          <p className="text-xs text-center text-muted-foreground mt-3">
            Powered by intelligent AI to answer all your service inquiries
          </p>
        </CardContent>
      </Card>

      {/* Inquiry Topics */}
      <div className="space-y-3">
        <h2 className="text-lg font-semibold text-foreground">Common Inquiries</h2>
        <div className="space-y-3">
          {inquiryTopics.map((topic, index) => {
            const Icon = topic.icon
            return (
              <Card 
                key={index} 
                className="hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => handleInquiryClick(topic.title)}
              >
                <CardContent className="flex items-start gap-4 p-4">
                  <div className={`flex h-12 w-12 items-center justify-center rounded-lg ${topic.bgColor} flex-shrink-0`}>
                    <Icon className={`h-6 w-6 ${topic.color}`} />
                  </div>
                  <div className="flex-1 space-y-1">
                    <h3 className="font-semibold text-foreground">{topic.title}</h3>
                    <p className="text-sm text-muted-foreground">{topic.description}</p>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>

      {/* Additional Info */}
      <Card className="bg-muted/50">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <MessageCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
            <div className="space-y-1">
              <h3 className="font-semibold text-sm text-foreground">Need Detailed Information?</h3>
              <p className="text-xs text-muted-foreground leading-relaxed">
                Our AI assistant is trained on all our services and can provide detailed answers about pricing, 
                service procedures, safety measures, booking process, and emergency support. Chat now for instant help!
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
