"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Phone, MessageCircle, MapPin, Clock, Mail, ExternalLink } from "lucide-react"

export default function ContactSection() {
  const phoneNumber = "9832046713"
  const whatsappNumber = "919832046713"

  const handleCall = () => {
    window.location.href = `tel:${phoneNumber}`
  }

  const handleWhatsApp = () => {
    window.open(`https://wa.me/${whatsappNumber}?text=Hello%20Prerna%20Gas%20Service,%20I%20would%20like%20to%20inquire%20about%20your%20services.`, '_blank')
  }

  return (
    <div className="space-y-6">
      {/* Header Card */}
      <Card className="border-primary/30 bg-gradient-to-br from-primary/5 to-transparent">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl text-balance">Get in Touch</CardTitle>
          <CardDescription className="text-base">
            Reach out to us for any service inquiries or emergency support
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Contact Buttons */}
      <div className="space-y-3">
        <Button 
          className="w-full h-auto py-4 flex items-center justify-between" 
          size="lg"
          onClick={handleCall}
        >
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary-foreground/20">
              <Phone className="h-5 w-5" />
            </div>
            <div className="text-left">
              <div className="text-sm font-semibold">Call Us Now</div>
              <div className="text-xs opacity-90">{phoneNumber}</div>
            </div>
          </div>
          <ExternalLink className="h-4 w-4 opacity-70" />
        </Button>

        <Button 
          className="w-full h-auto py-4 flex items-center justify-between bg-success hover:bg-success/90" 
          size="lg"
          onClick={handleWhatsApp}
        >
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-white/20">
              <MessageCircle className="h-5 w-5" />
            </div>
            <div className="text-left">
              <div className="text-sm font-semibold">WhatsApp Chat</div>
              <div className="text-xs opacity-90">{phoneNumber}</div>
            </div>
          </div>
          <ExternalLink className="h-4 w-4 opacity-70" />
        </Button>
      </div>

      {/* Contact Information */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Contact Information</CardTitle>
          <CardDescription>Our office and support details</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
            <Phone className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
            <div className="space-y-1 flex-1">
              <h3 className="font-semibold text-sm text-foreground">Phone</h3>
              <p className="text-sm text-muted-foreground">{phoneNumber}</p>
              <p className="text-xs text-muted-foreground">Available for calls and SMS</p>
            </div>
          </div>

          <div className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
            <MessageCircle className="h-5 w-5 text-success flex-shrink-0 mt-0.5" />
            <div className="space-y-1 flex-1">
              <h3 className="font-semibold text-sm text-foreground">WhatsApp</h3>
              <p className="text-sm text-muted-foreground">{phoneNumber}</p>
              <p className="text-xs text-muted-foreground">Quick responses via WhatsApp</p>
            </div>
          </div>

          <div className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
            <MapPin className="h-5 w-5 text-secondary flex-shrink-0 mt-0.5" />
            <div className="space-y-1 flex-1">
              <h3 className="font-semibold text-sm text-foreground">Service Area</h3>
              <p className="text-sm text-muted-foreground">North Bengal & Sikkim</p>
              <p className="text-xs text-muted-foreground">Serving all major cities and towns</p>
            </div>
          </div>

          <div className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
            <Clock className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
            <div className="space-y-1 flex-1">
              <h3 className="font-semibold text-sm text-foreground">Working Hours</h3>
              <p className="text-sm text-muted-foreground">Mon - Sat: 9:00 AM - 6:00 PM</p>
              <p className="text-sm text-muted-foreground">Sun: Emergency Services Only</p>
              <p className="text-xs text-destructive font-medium mt-1">24/7 Emergency Support Available</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Emergency Contact */}
      <Card className="border-destructive/30 bg-gradient-to-br from-destructive/5 to-transparent">
        <CardHeader>
          <CardTitle className="text-lg text-destructive">Emergency Services</CardTitle>
          <CardDescription>For urgent gas-related issues</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-sm text-muted-foreground text-pretty leading-relaxed">
            In case of gas leakage or emergency situations, contact us immediately. 
            Our emergency response team is available 24/7 to ensure your safety.
          </p>
          <Button 
            variant="destructive" 
            className="w-full"
            onClick={handleCall}
          >
            <Phone className="h-4 w-4 mr-2" />
            Call Emergency: {phoneNumber}
          </Button>
        </CardContent>
      </Card>

      {/* Additional Info */}
      <Card className="bg-muted/50">
        <CardContent className="p-4">
          <div className="space-y-2">
            <h3 className="font-semibold text-sm text-foreground">Prefer to Message?</h3>
            <p className="text-xs text-muted-foreground leading-relaxed">
              You can also reach us through WhatsApp for quick queries, service bookings, 
              or sharing images of your gas equipment. We typically respond within 30 minutes 
              during business hours.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
