"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { CheckCircle, Calendar, MapPin, Phone, User, Wrench, Home, Building2 } from "lucide-react"
import { sendNotification } from "@/app/actions/notifications"

export default function BookingSection() {
  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    serviceType: "",
    customerType: "",
    location: "",
    address: "",
    date: "",
    time: "",
    notes: ""
  })
  const [isSubmitted, setIsSubmitted] = useState(false)

  const services = [
    "LPG Burner Servicing",
    "Pipeline Installation",
    "Pipeline Repair",
    "Safety Inspection",
    "Leakage Checking",
    "Emergency Service"
  ]

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  const handleNext = () => {
    if (step < 3) setStep(step + 1)
  }

  const handleBack = () => {
    if (step > 1) setStep(step - 1)
  }

  const handleSubmit = async () => {
    // Send notification to app owner
    await sendNotification({
      type: 'booking',
      userName: formData.name,
      serviceType: `${formData.serviceType} (${formData.customerType})`,
      location: `${formData.location} - ${formData.address}`,
      contactNumber: formData.phone,
      message: `Preferred: ${formData.date} at ${formData.time}${formData.notes ? ` | Notes: ${formData.notes}` : ''}`,
      timestamp: new Date().toISOString(),
    })
    
    setIsSubmitted(true)
  }

  const resetForm = () => {
    setFormData({
      name: "",
      phone: "",
      serviceType: "",
      customerType: "",
      location: "",
      address: "",
      date: "",
      time: "",
      notes: ""
    })
    setStep(1)
    setIsSubmitted(false)
  }

  if (isSubmitted) {
    return (
      <Card className="border-success/30 bg-gradient-to-br from-success/5 to-transparent">
        <CardContent className="flex flex-col items-center justify-center p-8 text-center space-y-4">
          <div className="flex h-20 w-20 items-center justify-center rounded-full bg-success/20">
            <CheckCircle className="h-12 w-12 text-success" />
          </div>
          <div className="space-y-2">
            <h2 className="text-2xl font-bold text-foreground">Booking Confirmed!</h2>
            <p className="text-muted-foreground text-balance">
              Thank you, <span className="font-semibold text-foreground">{formData.name}</span>! 
              Your service request has been received.
            </p>
          </div>
          <Card className="w-full max-w-sm bg-card">
            <CardContent className="p-4 space-y-2 text-left">
              <div className="flex items-center gap-2 text-sm">
                <Wrench className="h-4 w-4 text-primary" />
                <span className="text-muted-foreground">Service:</span>
                <span className="font-medium">{formData.serviceType}</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <MapPin className="h-4 w-4 text-primary" />
                <span className="text-muted-foreground">Location:</span>
                <span className="font-medium">{formData.location}</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Calendar className="h-4 w-4 text-primary" />
                <span className="text-muted-foreground">Date:</span>
                <span className="font-medium">{formData.date} at {formData.time}</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Phone className="h-4 w-4 text-primary" />
                <span className="text-muted-foreground">Contact:</span>
                <span className="font-medium">{formData.phone}</span>
              </div>
            </CardContent>
          </Card>
          <div className="w-full max-w-sm space-y-2">
            <p className="text-sm text-muted-foreground text-pretty">
              We will contact you shortly at <span className="font-semibold text-foreground">{formData.phone}</span> to confirm your appointment.
            </p>
            <Button className="w-full" onClick={resetForm}>
              Book Another Service
            </Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Progress Indicator */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            {[1, 2, 3].map((s) => (
              <div key={s} className="flex flex-col items-center flex-1">
                <div
                  className={`flex h-10 w-10 items-center justify-center rounded-full font-semibold ${
                    s <= step ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'
                  }`}
                >
                  {s}
                </div>
                <span className="text-xs mt-1 text-muted-foreground">
                  {s === 1 ? 'Service' : s === 2 ? 'Details' : 'Confirm'}
                </span>
                {s < 3 && (
                  <div className={`h-0.5 w-full ${s < step ? 'bg-primary' : 'bg-muted'}`} />
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Step 1: Service Selection */}
      {step === 1 && (
        <Card>
          <CardHeader>
            <CardTitle>Select Service</CardTitle>
            <CardDescription>Choose the type of service you need</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="serviceType">Service Type *</Label>
              <Select value={formData.serviceType} onValueChange={(value) => handleInputChange("serviceType", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a service" />
                </SelectTrigger>
                <SelectContent>
                  {services.map((service) => (
                    <SelectItem key={service} value={service}>
                      {service}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Customer Type *</Label>
              <div className="grid grid-cols-2 gap-3">
                <Button
                  type="button"
                  variant={formData.customerType === "residential" ? "default" : "outline"}
                  className="h-auto py-4 flex flex-col items-center gap-2"
                  onClick={() => handleInputChange("customerType", "residential")}
                >
                  <Home className="h-6 w-6" />
                  <span className="text-sm">Residential</span>
                </Button>
                <Button
                  type="button"
                  variant={formData.customerType === "commercial" ? "default" : "outline"}
                  className="h-auto py-4 flex flex-col items-center gap-2"
                  onClick={() => handleInputChange("customerType", "commercial")}
                >
                  <Building2 className="h-6 w-6" />
                  <span className="text-sm">Commercial</span>
                </Button>
              </div>
            </div>

            <Button 
              className="w-full" 
              onClick={handleNext}
              disabled={!formData.serviceType || !formData.customerType}
            >
              Next: Enter Details
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Step 2: Contact & Location */}
      {step === 2 && (
        <Card>
          <CardHeader>
            <CardTitle>Your Details</CardTitle>
            <CardDescription>Enter your contact information and location</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name *</Label>
              <div className="relative">
                <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="name"
                  placeholder="Enter your name"
                  value={formData.name}
                  onChange={(e) => handleInputChange("name", e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number *</Label>
              <div className="relative">
                <Phone className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="phone"
                  type="tel"
                  placeholder="Enter your phone number"
                  value={formData.phone}
                  onChange={(e) => handleInputChange("phone", e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="location">City/Area *</Label>
              <div className="relative">
                <MapPin className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="location"
                  placeholder="e.g., Siliguri, Gangtok"
                  value={formData.location}
                  onChange={(e) => handleInputChange("location", e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="address">Full Address *</Label>
              <Textarea
                id="address"
                placeholder="Enter your complete address"
                value={formData.address}
                onChange={(e) => handleInputChange("address", e.target.value)}
                rows={3}
              />
            </div>

            <div className="flex gap-2">
              <Button variant="outline" onClick={handleBack} className="flex-1">
                Back
              </Button>
              <Button 
                onClick={handleNext}
                className="flex-1"
                disabled={!formData.name || !formData.phone || !formData.location || !formData.address}
              >
                Next: Schedule
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Step 3: Date & Time */}
      {step === 3 && (
        <Card>
          <CardHeader>
            <CardTitle>Schedule Service</CardTitle>
            <CardDescription>Choose your preferred date and time</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="date">Preferred Date *</Label>
              <Input
                id="date"
                type="date"
                value={formData.date}
                onChange={(e) => handleInputChange("date", e.target.value)}
                min={new Date().toISOString().split('T')[0]}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="time">Preferred Time *</Label>
              <Select value={formData.time} onValueChange={(value) => handleInputChange("time", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a time slot" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="09:00-11:00">Morning (9:00 AM - 11:00 AM)</SelectItem>
                  <SelectItem value="11:00-13:00">Late Morning (11:00 AM - 1:00 PM)</SelectItem>
                  <SelectItem value="14:00-16:00">Afternoon (2:00 PM - 4:00 PM)</SelectItem>
                  <SelectItem value="16:00-18:00">Evening (4:00 PM - 6:00 PM)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Additional Notes (Optional)</Label>
              <Textarea
                id="notes"
                placeholder="Any specific requirements or concerns?"
                value={formData.notes}
                onChange={(e) => handleInputChange("notes", e.target.value)}
                rows={3}
              />
            </div>

            <div className="flex gap-2">
              <Button variant="outline" onClick={handleBack} className="flex-1">
                Back
              </Button>
              <Button 
                onClick={handleSubmit}
                className="flex-1"
                disabled={!formData.date || !formData.time}
              >
                Confirm Booking
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
