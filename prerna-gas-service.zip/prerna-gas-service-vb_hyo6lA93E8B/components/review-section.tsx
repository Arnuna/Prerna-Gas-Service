"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Star, CheckCircle, User } from "lucide-react"
import { sendNotification } from "@/app/actions/notifications"

export default function ReviewSection() {
  const [rating, setRating] = useState(0)
  const [hoverRating, setHoverRating] = useState(0)
  const [name, setName] = useState("")
  const [review, setReview] = useState("")
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleSubmit = async () => {
    if (rating > 0 && name && review) {
      // Send notification to app owner
      await sendNotification({
        type: 'review',
        userName: name,
        rating: rating,
        message: review,
        timestamp: new Date().toISOString(),
      })
      
      setIsSubmitted(true)
      setTimeout(() => {
        setRating(0)
        setName("")
        setReview("")
        setIsSubmitted(false)
      }, 5000)
    }
  }

  if (isSubmitted) {
    return (
      <Card className="border-success/30 bg-gradient-to-br from-success/5 to-transparent">
        <CardContent className="flex flex-col items-center justify-center p-8 text-center space-y-4">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-success/20">
            <CheckCircle className="h-10 w-10 text-success" />
          </div>
          <div className="space-y-2">
            <h2 className="text-xl font-bold text-foreground">Thank You!</h2>
            <p className="text-sm text-muted-foreground text-balance">
              Your feedback has been submitted successfully. We appreciate your review!
            </p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-secondary/30">
      <CardHeader>
        <CardTitle className="text-xl flex items-center gap-2">
          <Star className="h-6 w-6 text-secondary fill-secondary" />
          Share Your Experience
        </CardTitle>
        <CardDescription>
          Your feedback helps us improve our services
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Rating */}
        <div className="space-y-3">
          <Label className="text-base">Rate Our Service *</Label>
          <div className="flex gap-2 justify-center py-2">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                type="button"
                onClick={() => setRating(star)}
                onMouseEnter={() => setHoverRating(star)}
                onMouseLeave={() => setHoverRating(0)}
                className="transition-transform hover:scale-110"
              >
                <Star
                  className={`h-10 w-10 ${
                    star <= (hoverRating || rating)
                      ? 'fill-secondary text-secondary'
                      : 'text-muted-foreground'
                  }`}
                />
              </button>
            ))}
          </div>
          {rating > 0 && (
            <p className="text-center text-sm text-muted-foreground">
              {rating === 5 && "Excellent! "}
              {rating === 4 && "Very Good! "}
              {rating === 3 && "Good! "}
              {rating === 2 && "Fair "}
              {rating === 1 && "Poor "}
              You rated us {rating} out of 5 stars
            </p>
          )}
        </div>

        {/* Name */}
        <div className="space-y-2">
          <Label htmlFor="reviewName">Your Name *</Label>
          <div className="relative">
            <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              id="reviewName"
              placeholder="Enter your name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* Review */}
        <div className="space-y-2">
          <Label htmlFor="reviewText">Your Feedback *</Label>
          <Textarea
            id="reviewText"
            placeholder="Share your experience with our service..."
            value={review}
            onChange={(e) => setReview(e.target.value)}
            rows={4}
          />
          <p className="text-xs text-muted-foreground">
            Minimum 10 characters ({review.length}/10)
          </p>
        </div>

        {/* Submit Button */}
        <Button 
          className="w-full" 
          size="lg"
          onClick={handleSubmit}
          disabled={rating === 0 || !name || review.length < 10}
        >
          <Star className="h-4 w-4 mr-2" />
          Submit Review
        </Button>

        {/* Sample Reviews */}
        <div className="pt-4 border-t space-y-4">
          <h3 className="font-semibold text-sm text-foreground">Recent Reviews</h3>
          
          <Card className="bg-muted/50">
            <CardContent className="p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-sm">Rajesh Kumar</span>
                <div className="flex gap-0.5">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star key={star} className="h-4 w-4 fill-secondary text-secondary" />
                  ))}
                </div>
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Excellent service! The technician was professional and completed the burner servicing quickly. Highly recommend Prerna Gas Service.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-muted/50">
            <CardContent className="p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-sm">Anita Sharma</span>
                <div className="flex gap-0.5">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star key={star} className="h-4 w-4 fill-secondary text-secondary" />
                  ))}
                </div>
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Very satisfied with the pipeline installation. The team was punctual and followed all safety protocols. Great work!
              </p>
            </CardContent>
          </Card>

          <Card className="bg-muted/50">
            <CardContent className="p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-sm">Suresh Pradhan</span>
                <div className="flex gap-0.5">
                  {[1, 2, 3, 4].map((star) => (
                    <Star key={star} className="h-4 w-4 fill-secondary text-secondary" />
                  ))}
                  <Star className="h-4 w-4 text-muted-foreground" />
                </div>
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Good service overall. Quick response for our commercial kitchen gas installation. Would use again.
              </p>
            </CardContent>
          </Card>
        </div>
      </CardContent>
    </Card>
  )
}
