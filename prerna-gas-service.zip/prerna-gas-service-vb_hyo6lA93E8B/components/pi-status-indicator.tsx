"use client"

import { useEffect, useState } from "react"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, XCircle, AlertCircle } from "lucide-react"
import { isPiBrowser, isPiSDKReady } from "@/lib/pi-payment-service"

export default function PiStatusIndicator() {
  const [inPiBrowser, setInPiBrowser] = useState(false)
  const [sdkReady, setSdkReady] = useState(false)

  useEffect(() => {
    const checkStatus = () => {
      setInPiBrowser(isPiBrowser())
      setSdkReady(isPiSDKReady())
    }

    checkStatus()

    // Recheck after a short delay to allow SDK to load
    const timer = setTimeout(checkStatus, 1000)
    return () => clearTimeout(timer)
  }, [])

  if (!inPiBrowser) {
    return null // Hide indicator when not in Pi Browser
  }

  return (
    <div className="fixed bottom-20 right-4 z-50">
      <Badge 
        variant={sdkReady ? "default" : "secondary"}
        className="flex items-center gap-2 px-3 py-2"
      >
        {sdkReady ? (
          <>
            <CheckCircle className="h-3 w-3" />
            <span className="text-xs">Pi SDK Ready</span>
          </>
        ) : (
          <>
            <AlertCircle className="h-3 w-3" />
            <span className="text-xs">Pi SDK Loading...</span>
          </>
        )}
      </Badge>
    </div>
  )
}
