"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { 
  CreditCard, 
  Smartphone, 
  Banknote, 
  CheckCircle, 
  AlertCircle,
  Receipt,
  ArrowRight,
  Coins
} from "lucide-react"
import { 
  SERVICE_PRICING, 
  generateUPILink, 
  generateWhatsAppPaymentRequest,
  generateOrderId,
  formatCurrency,
  calculateCharges,
  type PaymentData
} from "@/lib/payment-service"
import { 
  createPiPayment,
  convertINRToPi,
  formatPiAmount,
  isPiBrowser,
  isPiSDKReady
} from "@/lib/pi-payment-service"
import { usePiNetworkAuthentication } from "@/hooks/use-pi-network-authentication"
import { sendPaymentNotification } from "@/app/actions/notifications"

export default function PaymentSection() {
  const [step, setStep] = useState<'select' | 'details' | 'payment' | 'success'>("select")
  const [selectedService, setSelectedService] = useState<string>("")
  const [customerName, setCustomerName] = useState("")
  const [customerPhone, setCustomerPhone] = useState("")
  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'cash' | 'whatsapp' | 'pi'>()
  const [orderId, setOrderId] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)
  const [piPaymentId, setPiPaymentId] = useState<string>("")
  const [piTransactionId, setPiTransactionId] = useState<string>("")
  const [isInPiBrowser, setIsInPiBrowser] = useState(false)
  const [hasPiSDK, setHasPiSDK] = useState(false)
  
  // Pi Network authentication
  const { isAuthenticated: isPiAuthenticated, piAccessToken, authMessage, error: piError } = usePiNetworkAuthentication()
  
  // Check if running in Pi Browser and if Pi SDK is available
  useEffect(() => {
    const checkPiAvailability = () => {
      const piSdkExists = typeof window !== 'undefined' && 
                          typeof window.Pi !== 'undefined' && 
                          window.Pi !== null &&
                          typeof window.Pi.createPayment === 'function'
      
      setHasPiSDK(piSdkExists)
      setIsInPiBrowser(piSdkExists)
      
      console.log('[v0] Pi SDK check:', {
        hasWindow: typeof window !== 'undefined',
        hasPiObject: typeof window !== 'undefined' && typeof window.Pi !== 'undefined',
        hasCreatePayment: piSdkExists,
        sdkReady: piSdkExists
      })
    }

    // Initial check
    checkPiAvailability()

    // Recheck after delays to allow SDK to fully load
    const timer1 = setTimeout(checkPiAvailability, 500)
    const timer2 = setTimeout(checkPiAvailability, 1500)
    const timer3 = setTimeout(checkPiAvailability, 3000)
    
    return () => {
      clearTimeout(timer1)
      clearTimeout(timer2)
      clearTimeout(timer3)
    }
  }, [])

  const selectedServiceData = SERVICE_PRICING.find(s => s.name === selectedService)
  const charges = selectedServiceData ? calculateCharges(selectedServiceData.basePrice) : null

  const handleServiceSelect = (serviceName: string) => {
    setSelectedService(serviceName)
    setStep("details")
  }

  const handleDetailsSubmit = () => {
    if (customerName && customerPhone) {
      const newOrderId = generateOrderId()
      setOrderId(newOrderId)
      setStep("payment")
    }
  }

  const handlePayment = async (method: 'upi' | 'cash' | 'whatsapp' | 'pi') => {
    if (!selectedServiceData || !charges) return
    
    setIsProcessing(true)
    setPaymentMethod(method)

    const paymentData: PaymentData = {
      orderId,
      customerName,
      customerPhone,
      serviceType: selectedService,
      amount: charges.total,
      paymentMethod: method,
      status: method === 'cash' ? 'pending' : 'pending',
      timestamp: new Date().toISOString(),
    }

    // Send notification to owner
    await sendPaymentNotification(paymentData)

    if (method === 'pi') {
      // Official Pi SDK v2.0 payment flow - NO wallet addresses
      
      // Validate Pi SDK availability
      if (!hasPiSDK || !isPiSDKReady()) {
        setIsProcessing(false)
        alert('Pi SDK not available. Please ensure you are using Pi Browser and refresh the app.')
        return
      }

      // Validate Pi authentication
      if (!isPiAuthenticated || !piAccessToken) {
        setIsProcessing(false)
        alert('Pi Network authentication required. Please refresh the app and try again.')
        return
      }

      // Prepare payment data
      const piPaymentData = {
        orderId,
        amount: charges.total,
        memo: `Prerna Gas - ${selectedService} - #${orderId}`,
        metadata: {
          customerName,
          customerPhone,
          serviceType: selectedService,
        }
      }

      console.log('[v0] Starting Pi payment:', { 
        orderId, 
        service: selectedService,
        amountINR: charges.total 
      })

      // Official Pi SDK v2.0 callback-based payment
      createPiPayment(
        piPaymentData,
        // onSuccess callback
        (paymentId: string, txid: string) => {
          console.log('[v0] ✓ Payment completed successfully')
          setPiPaymentId(paymentId)
          setPiTransactionId(txid)
          setIsProcessing(false)
          setStep("success")
        },
        // onCancel callback
        (paymentId: string) => {
          console.log('[v0] ✗ Payment cancelled')
          setIsProcessing(false)
          alert('Payment was cancelled. You can try again or use another payment method.')
        },
        // onError callback
        (error: Error) => {
          console.error('[v0] ✗ Payment failed:', error.message)
          setIsProcessing(false)
          alert(`Payment failed: ${error.message}. Please try again.`)
        }
      )
    } else if (method === 'upi') {
      // Generate UPI link and open
      const upiLink = generateUPILink({
        amount: charges.total,
        name: "Prerna Gas Service",
        note: `${selectedService} - ${orderId}`,
      })
      window.location.href = upiLink
      
      // Simulate payment processing
      setTimeout(() => {
        setIsProcessing(false)
        setStep("success")
      }, 2000)
    } else if (method === 'whatsapp') {
      // Open WhatsApp with payment request
      const whatsappUrl = generateWhatsAppPaymentRequest({
        orderId,
        customerName,
        serviceType: selectedService,
        amount: charges.total,
      })
      window.open(whatsappUrl, '_blank')
      
      setIsProcessing(false)
      setStep("success")
    } else if (method === 'cash') {
      setIsProcessing(false)
      setStep("success")
    }
  }

  const resetPayment = () => {
    setStep("select")
    setSelectedService("")
    setCustomerName("")
    setCustomerPhone("")
    setPaymentMethod(undefined)
    setOrderId("")
  }

  return (
    <div className="space-y-6">
      {/* Step: Service Selection */}
      {step === "select" && (
        <div className="space-y-4">
          <div className="text-center space-y-2">
            <h2 className="text-2xl font-bold text-balance">Select Service for Payment</h2>
            <p className="text-muted-foreground text-pretty">
              Choose the service you want to pay for
            </p>
          </div>

          <div className="grid gap-3">
            {SERVICE_PRICING.map((service) => (
              <Card 
                key={service.name}
                className="cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => handleServiceSelect(service.name)}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-base leading-tight">{service.name}</CardTitle>
                      <CardDescription className="text-sm mt-1">{service.description}</CardDescription>
                    </div>
                    <Badge variant={service.category === 'commercial' ? 'secondary' : 'outline'} className="ml-2 shrink-0">
                      {service.category}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold text-primary">
                      {formatCurrency(service.basePrice)}
                    </span>
                    <Button size="sm" variant="ghost">
                      Select <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Step: Customer Details */}
      {step === "details" && selectedServiceData && (
        <div className="space-y-4">
          <Button variant="ghost" onClick={() => setStep("select")} className="mb-2">
            ← Back to Services
          </Button>

          <Card>
            <CardHeader>
              <CardTitle>Selected Service</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between items-start">
                <div>
                  <p className="font-semibold">{selectedService}</p>
                  <p className="text-sm text-muted-foreground">{selectedServiceData.description}</p>
                </div>
                <span className="text-xl font-bold text-primary">
                  {formatCurrency(selectedServiceData.basePrice)}
                </span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Customer Details</CardTitle>
              <CardDescription>Enter your contact information</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="customerName">Full Name</Label>
                <Input 
                  id="customerName"
                  placeholder="Enter your name"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="customerPhone">Mobile Number</Label>
                <Input 
                  id="customerPhone"
                  placeholder="98XXXXXXXX"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  maxLength={10}
                />
              </div>

              <Button 
                onClick={handleDetailsSubmit}
                disabled={!customerName || !customerPhone || customerPhone.length !== 10}
                className="w-full"
                size="lg"
              >
                Proceed to Payment
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Step: Payment Method */}
      {step === "payment" && charges && selectedServiceData && (
        <div className="space-y-4">
          <Button variant="ghost" onClick={() => setStep("details")} className="mb-2">
            ← Back to Details
          </Button>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Receipt className="h-5 w-5" />
                Payment Summary
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Service Charge</span>
                  <span>{formatCurrency(charges.baseAmount)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>GST (18%)</span>
                  <span>{formatCurrency(charges.gst)}</span>
                </div>
                <Separator />
                <div className="flex justify-between font-bold text-lg">
                  <span>Total Amount</span>
                  <span className="text-primary">{formatCurrency(charges.total)}</span>
                </div>
              </div>

              <div className="bg-muted p-3 rounded-lg space-y-1 text-sm">
                <p><strong>Order ID:</strong> {orderId}</p>
                <p><strong>Customer:</strong> {customerName}</p>
                <p><strong>Phone:</strong> {customerPhone}</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Choose Payment Method</CardTitle>
              <CardDescription>Select how you want to pay</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {/* Pi Payment Button - Only show if window.Pi SDK is fully ready */}
              {hasPiSDK && isPiAuthenticated && (
                <Button
                  onClick={() => handlePayment('pi')}
                  disabled={isProcessing}
                  className="w-full justify-start h-auto py-4 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white shadow-md"
                  size="lg"
                >
                  <Coins className="mr-3 h-5 w-5" />
                  <div className="text-left flex-1">
                    <div className="font-semibold">Pay with Pi Network</div>
                    <div className="text-xs opacity-90">
                      {formatPiAmount(convertINRToPi(charges?.total || 0))} Pi
                    </div>
                  </div>
                  <ArrowRight className="h-4 w-4" />
                </Button>
              )}
              
              {/* Show loading state if Pi SDK is initializing */}
              {hasPiSDK && !isPiAuthenticated && !piError && (
                <Card className="border-purple-200 bg-purple-50">
                  <CardContent className="pt-4 pb-4">
                    <div className="flex items-start gap-3">
                      <Coins className="h-5 w-5 text-purple-600 mt-0.5 animate-pulse" />
                      <div className="flex-1">
                        <div className="font-semibold text-sm text-purple-900">
                          Initializing Pi Network...
                        </div>
                        <div className="text-xs text-purple-700 mt-1">
                          {authMessage}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
              
              {/* Show error if Pi authentication failed */}
              {hasPiSDK && piError && (
                <Card className="border-red-200 bg-red-50">
                  <CardContent className="pt-4 pb-4">
                    <div className="flex items-start gap-3">
                      <AlertCircle className="h-5 w-5 text-red-600 mt-0.5" />
                      <div className="flex-1">
                        <div className="font-semibold text-sm text-red-900">
                          Pi Authentication Failed
                        </div>
                        <div className="text-xs text-red-700 mt-1">
                          {piError}. Please use UPI, WhatsApp, or Cash payment.
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Show warning message when window.Pi doesn't exist */}
              {!hasPiSDK && (
                <Card className="border-purple-200 bg-purple-50">
                  <CardContent className="pt-4 pb-4">
                    <div className="flex items-start gap-3">
                      <AlertCircle className="h-5 w-5 text-purple-600 mt-0.5" />
                      <div className="flex-1">
                        <div className="font-semibold text-sm text-purple-900">
                          Pi Payment Available in Pi Browser Only
                        </div>
                        <div className="text-xs text-purple-700 mt-1">
                          To pay with Pi Network, please open this app in Pi Browser. Use UPI, WhatsApp, or Cash payment as alternatives.
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              <Button
                onClick={() => handlePayment('upi')}
                disabled={isProcessing}
                className="w-full justify-start h-auto py-4"
                variant="outline"
                size="lg"
              >
                <Smartphone className="mr-3 h-5 w-5" />
                <div className="text-left flex-1">
                  <div className="font-semibold">Pay via UPI</div>
                  <div className="text-xs text-muted-foreground">PhonePe, Google Pay, Paytm, etc.</div>
                </div>
                <ArrowRight className="h-4 w-4" />
              </Button>

              <Button
                onClick={() => handlePayment('whatsapp')}
                disabled={isProcessing}
                className="w-full justify-start h-auto py-4"
                variant="outline"
                size="lg"
              >
                <CreditCard className="mr-3 h-5 w-5" />
                <div className="text-left flex-1">
                  <div className="font-semibold">WhatsApp Payment Link</div>
                  <div className="text-xs text-muted-foreground">Get payment details on WhatsApp</div>
                </div>
                <ArrowRight className="h-4 w-4" />
              </Button>

              <Button
                onClick={() => handlePayment('cash')}
                disabled={isProcessing}
                className="w-full justify-start h-auto py-4"
                variant="outline"
                size="lg"
              >
                <Banknote className="mr-3 h-5 w-5" />
                <div className="text-left flex-1">
                  <div className="font-semibold">Cash on Service</div>
                  <div className="text-xs text-muted-foreground">Pay when technician arrives</div>
                </div>
                <ArrowRight className="h-4 w-4" />
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Step: Success */}
      {step === "success" && charges && (
        <div className="space-y-4">
          <Card className="border-success">
            <CardContent className="pt-6 text-center space-y-4">
              <div className="flex justify-center">
                <div className="bg-success/10 p-4 rounded-full">
                  <CheckCircle className="h-12 w-12 text-success" />
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="text-2xl font-bold">
                  {paymentMethod === 'cash' ? 'Order Confirmed!' : 'Payment Initiated!'}
                </h3>
                <p className="text-muted-foreground text-pretty">
                  {paymentMethod === 'cash' 
                    ? 'Your service booking is confirmed. Please pay the technician when they arrive.'
                    : paymentMethod === 'pi'
                    ? 'Your Pi payment has been processed! Our team will verify the transaction and confirm your booking.'
                    : paymentMethod === 'whatsapp'
                    ? 'Payment request sent via WhatsApp. Complete the payment and our team will confirm your booking.'
                    : 'Complete the payment in your UPI app. Our team will confirm your booking shortly.'}
                </p>
              </div>

              <div className="bg-muted p-4 rounded-lg space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="font-medium">Order ID:</span>
                  <span className="font-mono">{orderId}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Amount:</span>
                  <span className="font-bold text-primary">
                    {formatCurrency(charges.total)}
                    {paymentMethod === 'pi' && piPaymentId && (
                      <span className="ml-2 text-purple-600">
                        ({formatPiAmount(convertINRToPi(charges.total))} Pi)
                      </span>
                    )}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Payment Method:</span>
                  <span className="capitalize">
                    {paymentMethod === 'pi' ? 'Pi Network' : paymentMethod}
                  </span>
                </div>
                {paymentMethod === 'pi' && piTransactionId && (
                  <>
                    <div className="flex justify-between">
                      <span className="font-medium">Payment ID:</span>
                      <span className="font-mono text-xs">{piPaymentId.slice(0, 20)}...</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-medium">Transaction ID:</span>
                      <span className="font-mono text-xs">{piTransactionId.slice(0, 20)}...</span>
                    </div>
                  </>
                )}
              </div>

              <div className="bg-accent p-3 rounded-lg flex items-start gap-2 text-sm">
                <AlertCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <p className="text-left text-pretty">
                  Our team will contact you at <strong>{customerPhone}</strong> to confirm your service booking within 30 minutes.
                </p>
              </div>

              <Button onClick={resetPayment} size="lg" className="w-full">
                Make Another Payment
              </Button>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
